import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Grid from '@material-ui/core/Grid';


const addresses = ['1 Material-UI Drive', 'Reactville', 'Anytown', '99999', 'USA'];
const pensions = [
  { name: 'Person Name', detail: 'John' },
  { name: 'Email', detail: 'john@gmail.com' },
  { name: 'Address', detail: 'East Legon' },
  { name: 'Phone', detail: '024413213' },
];

const useStyles = makeStyles(theme => ({
  listItem: {
    padding: theme.spacing(1, 0),
  },
  total: {
    fontWeight: '700',
  },
  title: {
    marginTop: theme.spacing(2),
  },
}));

export default function Review() {
  const classes = useStyles();

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Review summary
      </Typography>
      <List disablePadding>
       
        
      </List>
      <Grid container spacing={2}>
        <Grid item container direction="column" xs={12} sm={6}>
          <Typography variant="h6" gutterBottom className={classes.title}>
            Personal details
          </Typography>
          <Grid container>
            {pensions.map(pension => (
              <React.Fragment key={pension.name}>
                <Grid item xs={6}>
                  <Typography gutterBottom>{pension.name}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography gutterBottom>{pension.detail}</Typography>
                </Grid>
              </React.Fragment>
            ))}
          </Grid>
        </Grid>
        
      </Grid>
    </React.Fragment>
  );
}
